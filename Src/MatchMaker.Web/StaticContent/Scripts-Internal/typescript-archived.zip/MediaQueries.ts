module MediaQueries { 
    export var Queries: MediaQueryList[];
    export var Sizes: number[] = [300, 500, 700, 1000];

    function GetMaxQuery(size: number): string { 
        return "(max-width:" + size + "px)";
    
    }

    function GetMinQuery(size: number): string { 
        return "(min-width:" + size + "px)";
    }


    function CreateQueries():void
    { 
        Queries = [];
        for (var x = 0; x < Sizes.length*2; x++) { 
            var current;
            current =x<Sizes.length/2 ?  GetMaxQuery(Sizes[x]) : GetMinQuery(Sizes[x - Sizes.length]);
            Queries.push(window.matchMedia("screen and " + current));
        }

    }

    export function GetQueries():MediaQueryList[] { 
        if (Queries == undefined) { 
            CreateQueries();
        }
        return Queries;
    }


}