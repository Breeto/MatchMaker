/// <reference path="../Scripts-External/jquery.d.ts" />   

class MulticastEvent { 
    private Handlers: { (parameter): void; }[];
    private HandlerObjects: any[];

    FireEvent(parameter) {
        this.Handlers.forEach(function (funct) {
            funct(parameter);
        });
        };

        constructor () { 
            this.Handlers = new Array();
            this.HandlerObjects = new Array();
        }

        AddHandler(handler:{ (parameter): void; }, object:any) { 
            this.Handlers.push(handler);
            this.HandlerObjects.push(object);
        
        }

        RemoveHandler(object: any) { 
            var position = $.inArray(object, this.HandlerObjects);
        
            if (~position) { 
                this.HandlerObjects.splice(position, 1);
                this.Handlers.splice(position, 1);
            }
        }

}