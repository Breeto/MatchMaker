class Map { 
    Name: string;
    ImagePath: string;
    Id: string;
    GameId: string;
}


class MapWinLossInformation { 
    Map: Map;
    Wins: number;
    TimesPlayed: number;
    Percentage: number;
}

class LinkedPlayer { 
    Name: string;
    ID: string;
    Matrix: number[];
    GameMatrix: number[];
    RecentWinsLosses: number[];
    MapWinPercentages: MapWinLossInformation[];
}


